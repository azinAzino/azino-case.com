<?php $__env->startSection('title'); ?>
<?php echo e(__('FAQ')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('faq'); ?>
nav-line__link_active
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="content">
	<div id="react">
		<div data-reactroot="" class="Container" style="position: relative;">
			<div class="HelpMd">
				<div class="HelpMd__wrapper">
					<div class="HelpMd__header"> <?php echo e(__('FAQ')); ?> </div>
					<div class="HelpMd__faq-row">
						<div class="HelpMd__faq-col">
							<div class="Faq">
								<div class="Faq__block">
									<div class="Faq__header"> <?php echo e(__('Game')); ?> </div>
									<div>
										<div name="qa-1">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('Game')); ?>? </span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('Click the Login or Register button in the upper right corner of the site. Choose your favorite social network: VKontakte, Facebook or Odnoklassniki, after which you will be taken to a special access confirmation page. Click the "Confirm" button and registration will automatically end. In the future, to log in you just have to click on the login button and select the social network that you used when registering.')); ?> </div>
												</div>
											</div>
										</div>
									</div>
									
									<div>
										<div name="qa-3">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('What is the essence of the game?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('The main page contains a list of all cases. Each case has 12 cells. Click the "Start Game" button and click on any of the 12 cells in the playing field. After that, the cell will open and you will see which of the guaranteed winnings received. Winnings are automatically credited to your balance. You can open the next cell on the field or see what the other winnings were. The cost of opening each subsequent cell is increased by 20%.')); ?></div>
												</div>
											</div>
										</div>
									</div>
									<div>
										<div name="qa-4">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('How many cells can be opened in 1 game?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('You can open 1 to 3 cells in one game session. Winnings are not repeated. Accordingly, each discovery increases your chance of getting the maximum win!')); ?></div>
												</div>
											</div>
										</div>
									</div>
									<div>
										<div name="qa-5">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('How is the "Rating" page and TOP-10 formed on the main page?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('The ranking position is calculated based on the total winnings. Thus, the more you win, the higher your position in the ranking. Only the top ten best players appear on the home page.')); ?></div>
												</div>
											</div>
										</div>
									</div>
									<div>
										<div name="qa-6">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('Can I register more than 1 account?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('No, each user can register only one account. For multiple registration, we can block all user accounts. The withdrawal of the balance on blocked accounts is not performed.')); ?></div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="Faq__block">
									<div class="Faq__header"> <?php echo e(__('Deposits and Withdrawals')); ?></div>
									<div>
										<div name="qa-7">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('How to replenish the balance?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('Click the "Refill" button in the upper right corner of the screen. Enter the payment amount in numbers without spaces, periods or commas. Choose a convenient payment system and click the "Recharge" button. After that, you will be redirected to the site of the payment system, where you need to complete the payment. After the payment is completed, you will be redirected back to Egger.')); ?></div>
												</div>
											</div>
										</div>
									</div>
									<div>
										<div name="qa-8">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('Minimum balance replenishment amount?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('The minimum replenishment amount is 250 dollars.')); ?></div>
												</div>
											</div>
										</div>
									</div>
									
									<div>
										<div name="qa-10">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('How to withdraw winnings?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('Click the "Output" button in the upper right corner of the screen. Enter the amount to pay out, wallet number and select a payment system. Press the "Withdraw" button, after which the funds will be debited from the balance and your payment order will immediately go into processing.')); ?></div>
												</div>
											</div>
										</div>
									</div>
									
									<div>
										<div name="qa-12">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('How to track the payment status?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('The status of the payment ordered can always be found on the "Finance" page, the link to which is located on the "My profile" page.')); ?></div>
												</div>
											</div>
										</div>
									</div>
									<div>
										<div name="qa-13">
											<div class="Faq__qa">
												<div class="Faq__q"> <span role="button" class="Faq__q-text"> <?php echo e(__('Minimum payout amount?')); ?></span> </div>
												<div class="Faq__a">
													<div class="Faq__a-text"> <?php echo e(__('The minimum payout amount is $1500.')); ?></div>
												</div>
											</div>
										</div>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foo_help'); ?>
footer__nav-link_active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_help'); ?>
header-menu__link_active
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/faq.blade.php ENDPATH**/ ?>