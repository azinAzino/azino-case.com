<?php $__env->startSection('page', trans('ticketit::admin.category-create-title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="well bs-component">
        <?php echo CollectiveForm::open(['route'=> $setting->grab('admin_route').'.category.store', 'method' => 'POST', 'class' => 'form-horizontal']); ?>

            <legend><?php echo e(trans('ticketit::admin.category-create-title')); ?></legend>
            <?php echo $__env->make('ticketit::admin.category.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo CollectiveForm::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($master, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/vendor/kordy/ticketit/src/Views/bootstrap3/admin/category/create.blade.php ENDPATH**/ ?>