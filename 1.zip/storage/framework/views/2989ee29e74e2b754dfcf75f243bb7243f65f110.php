<?php $__env->startSection('title'); ?>
<?php echo e(__('Profile')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
	<?php $settings = \DB::table('settings')->where('id', 1)->first();
	$my_refs = \DB::table('users')->where('ref_user', Auth::user()->id)->count();
	$zarabotal = \DB::table('operations')->where('ref_user', Auth::user()->id)->where('type', 0)->where('status', 1)->sum('amount');
	if ($zarabotal == '') {
		$zarabotal = 0;
	}
	?>
	<div class="profile-row">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
					<div class="profile-row__user-info-wrapper">
						<div class="row">
							<div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
								<div class="profile-row__user-avatar">
									<div class="profile-row__user-avatar-wrapper">
										<img src="<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->userame); ?>" class="profile-row__user-avatar-img">
									</div>
								</div>
								<div class="profile-row__user-name"><?php echo e(Auth::user()->username); ?></div>
								<div class="profile-row__balance">
									<img src="/img/system/money__icon_yellow.png" alt="" class="profile-row__balance-img">
									<?php echo e(Auth::user()->money); ?><span class="dollar yellow">$</span>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
								<div class="profile-row__button-line button-line">
									<button class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_hlight modal-toggle" data-toggle="add-cash"><?php echo e(__('Top up balance')); ?></button>
									<button class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_trans-hlight modal-toggle" data-toggle="remove-cash"><?php echo e(__('Withdraw funds')); ?></button>
									<a href="/logout" onclick="return confirm(window.__('Are you sure you want to sign out?'))" class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_trans-dark"><?php echo e(__('Logout')); ?></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
					<?php if(isset($show_swift) && $show_swift): ?> <?php echo $__env->make('finance.swift', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
					<?php if(isset($show_tax) && $show_tax): ?> <?php echo $__env->make('finance.tax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
					<div class="row">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<div class="profile-row__user-stat-block">
								<div class="profile-row__user-stat-value">
									<?php echo e(__('Opened cases')); ?>:&nbsp;<span><?php echo e(Auth::user()->opened); ?></span><br>
									<?php echo e(__('For the amount')); ?>:&nbsp;<span><?php echo e(Auth::user()->profit); ?><span class="dollar yellow">$</span></span>
									<img src="/img/system/egg-icon_64.png" alt="" class="profile-row__user-stat-img">
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<div class="profile-row__user-stat-block">
								<div class="profile-row__user-stat-value profile-row__user-stat-value_alone">
									<?php echo e(__('Top place')); ?>:&nbsp;<span><?php echo e($usr_pos); ?></span>
									<img src="/img/system/position-icon_64.png" alt="" class="profile-row__user-stat-img">
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<div class="profile-row__user-stat-block">
								<div class="profile-row__user-stat-value">
									<?php echo e(__('Invited')); ?>:&nbsp;<span><?php echo e($my_refs); ?></span><br>
									<?php echo e(__('Earned')); ?>:&nbsp;<span><?php echo e($zarabotal); ?><span class="dollar yellow">$</span></span>
									<img src="/img/system/users-icon_64.png" alt="" class="profile-row__user-stat-img">
								</div>
							</div>
						</div>
					</div>
					<div class="lk-tabs button-line">
						<a href="/profile" class="lk-tabs__lk-tab button-line__button button-rounding button-rounding_med button-rounding_trans-dark button-rounding_active">
							<?php echo e(__('Game history')); ?>

						</a>
						
						<a href="/profile/finance" class="lk-tabs__lk-tab button-line__button button-rounding button-rounding_med button-rounding_dark">
							<?php echo e(__('Finance')); ?>

						</a>
					</div>
					<div id="game-history" class="lk-block game-history">
						<div class="lk-block__header">
							<div class="lk-block__header-line"></div>
							<div class="lk-block__header-text"><?php echo __('Game <span>history</span>'); ?></div>
							<div class="lk-block__header-line"></div>
						</div>
						<div class="game__contains">
							<div class="row">
								<?php if(isset($history) && !empty($history)): ?>
								<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if(isset($h->image)): ?>
								<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
									<div class="game__contains-cell game__contains-cell_none">

										<div class="game__contains-img-wrapper game__contains-img-wrapper_with-header">
											<div class="game__contains-header"><?php echo e(__($h->name)); ?></div>
											<div class="game__contains-egg-glow"></div><img src="<?php echo e($h->image); ?>" alt="" class="game__contains-egg-img">
										</div>

									</div>
								</div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</div>
							<div class="button-line button-line_center <?php if(count($history) != 24): ?> hidden <?php endif; ?>">
								<button class="button-line__button button-rounding button-rounding_trans-big button-rounding_trans-hlight" id="profile_games_more" data-user-id="<?php echo e(Auth::user()->id); ?>" data-last-game="<?php echo e($last_g); ?> ">
									<?php echo e(__('Show more')); ?>

								</button>
							</div>
							<div class="button-line button-line_center <?php if(isset($history) && count($history) != 0): ?> hidden <?php endif; ?>">
								<p><?php echo e(__('You have not played any balance games yet.')); ?></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/profile.blade.php ENDPATH**/ ?>