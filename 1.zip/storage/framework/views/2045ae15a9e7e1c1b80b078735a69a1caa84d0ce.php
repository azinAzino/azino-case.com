<?php $__env->startSection('title'); ?>
Отзывы игроков
<?php $__env->stopSection(); ?>

<?php $__env->startSection('opinions'); ?>
nav-line__link_active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
	<?php 
		$settings = \DB::table('settings')->where('id', 1)->first();
	?>
	<div class="container">
        <div class="button-line"><a href="/" class="button-line__button button-rounding button-rounding_trans-big button-rounding_trans-hlight">Назад
                <div class="button-line__button-icon"></div></a>
            <a class="button-line__button button-line__button_right button-rounding button-rounding_trans-big button-rounding_trans-light" href="<?php echo e($settings->vk_group); ?>" target="_blank">Написать отзыв</a>
        </div>
    </div>
    <div class="reviews-block">
        <div class="container">
            <div class="row">
                <div class="reviews-block__header-line top-block__header">
                    <div class="top-block__header-line"></div>
                    <div class="top-block__header-text"><span>Отзывы</span>&nbsp;игроков</div>
                    <div class="top-block__header-line"></div>
                </div>
				<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="reviews-block__reviews-card-wrapper">
					<div class="reviews-block__reviews-card">
						<div class="reviews-block__header-wrapper">
							<div class="reviews-block__header"><a href="<?php echo e($r->user_link); ?>" target="_blank">
									<div class="reviews-block__ava-wrapper"><img src="<?php echo e($r->user_avatar); ?>" alt="" class="reviews-block__ava-img"></div><?php echo e($r->username); ?></a>
								<div class="reviews-block__header-border"></div>
							</div>
							<div class="reviews-block__reviews-date text-block text-block_color_gray"><?php echo e($r->created_at); ?></div>
						</div>
						<div class="reviews-block__reviews-text text-block"><?php echo e($r->text); ?></div>
						<div class="reviews-block__reviews-file">
							<div class="reviews-block__reviews-file-header text-block text-block_color_gray">
								<?php if(isset($r->photo) && $r->photo != ''): ?>
								<img src="https://219316.selcdn.ru/egger/clip-icon.png" alt="" class="reviews-block__reviews-file-icon">Прикрепил:
								<?php endif; ?>
								<div class="reviews-block__reviews-link text-block"><a href="<?php echo e($r->opinion_link); ?>" target="_blank" class="text-block__link">Оригинал отзыва</a></div>
							</div>
							<?php if(isset($r->photo) && $r->photo != ''): ?>)
							<img src="<?php echo e($r->photo); ?>" alt="" class="reviews-block__reviews-file-img">
							<?php endif; ?>
						</div>
					</div>
				</div> 
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foo_opinions'); ?>
footer__nav-link_active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('header_opinions'); ?>
header-menu__link_active
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/opinions.blade.php ENDPATH**/ ?>