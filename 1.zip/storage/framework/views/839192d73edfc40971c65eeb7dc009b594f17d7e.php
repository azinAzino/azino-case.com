<?php echo $__env->make("layouts.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(Auth::guest()): ?>
<body data-user-id="0" data-user-balance="0">
<?php else: ?>
<body data-user-id="<?php echo e(Auth::user()->id); ?>" data-user-balance="<?php if(Auth::user()->deposit == 0 && Auth::user()->money == 0): ?> <?php echo e(Auth::user()->bonus_money); ?> <?php else: ?> <?php echo e(Auth::user()->money); ?> <?php endif; ?>">
<?php endif; ?>
<?php if(!Auth::guest() && (float)Auth::user()->deposit <= 0): ?>
<div class="bonus-banner_auth">
    <div class="hidden-xs container-fluid">
        <button data-toggle="bonus-modal" class="bonus-banner__button modal-toggle"> <?php echo e(__('Read')); ?> </button>
    </div>
</div>
<?php endif; ?>
<div class="main-wrapper <?php echo $__env->yieldContent('bonus'); ?>">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.live', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('modal'); ?>
<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<audio class="sound_heart" preload="auto">
    <source src="/img/system/sound/heart.mp3" type="audio/mpeg">
    <source src="/img/system/sound/heart.ogg" type="audio/ogg; codecs=vorbis">
</audio>
<audio class="sound_win" preload="auto">
    <source src="/img/system/sound/win.mp3" type="audio/mpeg">
    <source src="/img/system/sound/win.ogg" type="audio/ogg; codecs=vorbis">
</audio>
<script>locale = '<?php echo e(App::getLocale()); ?>'</script>
<script>
    window._translations = <?php echo cache('translations' . App::getLocale()); ?>;
</script>
<script type="text/javascript" src="/js/app.js"></script>
</body>
</html><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/layout.blade.php ENDPATH**/ ?>