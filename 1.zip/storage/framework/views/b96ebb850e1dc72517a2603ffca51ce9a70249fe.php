<?php $__env->startSection('title'); ?>
<?php echo e(trans($card->name)); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
        <div class="game" data-price="<?php echo e($card->cost); ?>">
            <div class="game__header">
                <div class="game__header-line"></div>
                <div class="game__header-text"><?php echo e(trans($card->name)); ?></div>
                <div class="game__header-line"></div>
            </div>
            <div class="game__game-field">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 col-lg-offset-2">
                        <div class="game__row game__row_none row">
                            <div class="game__info-layout game__info-layout_start">
                                <div class="game__button-wrapper">
                                    <button class="game__win-button button-rounding button-rounding_trans-big button-rounding_hlight game__win-button_start"><?php echo e(trans('Start the game for')); ?> <?php echo e($card->cost); ?><span class="dollar yellow">$</span></button>
                                </div>
                            </div>
                            <div class="game__info-layout game__info-layout_restart">
                                <div class="game__button-wrapper">
                                    <button class="game__win-button button-rounding button-rounding_trans-big button-rounding_hlight game__win-button_restart"><?php echo e(trans('Play again for')); ?> <?php echo e($card->cost); ?><span class="dollar yellow">$</span></button>
                                </div>
                            </div>
                            <div class="game__win-layout">
                                <div class="game__game-cell_win-cell game__game-cell_win-cell-start game__game-cell" data-class="game__game-cell_win-cell-start">
                                    <div class="game__img-wrapper">
                                        <div class="game__egg-glow game__egg-glow_main"></div>
                                        <img src="/img/system/egg200/egg1.png" alt="" class="game__egg-img game__egg-img_win" />
                                    </div>
                                    <div class="game__button-wrapper">
                                        <button class="game__win-button button-rounding button-rounding_trans-big button-rounding_hlight game__win-button_continue"><?php echo e(trans('Continue')); ?></button>
                                        <button class="game__win-button button-rounding button-rounding_trans-big button-rounding_light game__win-button_play_balance"><?php echo e(trans('Play for balance')); ?></button>
                                        <button class="game__win-button button-rounding button-rounding_trans-big button-rounding_trans-light game__win-button_show_all"><?php echo e(trans('Start over')); ?></button>
                                    </div>
                                </div>
                            </div>
                            <?php for($i = 0; $i < 12; $i++): ?> <div class="game__col col-xs-4 col-sm-4 col-md-3 col-lg-3">
                                <div class="game__game-cell game__game-cell_blue game__game-cell_close game__game-cell_item" id="egg<?php echo e($i); ?>" data-class="game__game-cell_close" data-cart-id="<?php echo e($card->id); ?>">
                                    <div class="game__img-wrapper">
                                        <img src="<?php echo e($card->item_image); ?>" alt="" class="game__egg-img game__egg-img_blue" />
                                        <div class="game__result-egg">
                                            <img src="/img/coins/150/null.png" alt="" class="game__egg-img game__egg-img_result" />
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="game__header">
        <div class="game__header-line"></div>
        <div class="game__subheader-text"><?php echo e(trans('Guaranteed winnings')); ?>:</div>
        <div class="game__header-line"></div>
    </div>
    <div class="game__contains">
        <div class="row">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
                <div class="game__contains-cell">
                    <div class="game__contains-img-wrapper">
                        <img src="<?php if(isset($i->image)): ?> <?php echo e($i->image); ?> <?php endif; ?>" alt="" class="game__contains-egg-img" />
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/cart.blade.php ENDPATH**/ ?>