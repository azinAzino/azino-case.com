<?php $__env->startSection('content'); ?>
<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<a href="/admin">Главная</a>
			<i class="fa fa-circle"></i>
		</li>
		<li>
			<span>Отзывы</span>
		</li>
	</ul>
</div>
<h1 class="page-title">Отзывы </h1>
<div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> <!-- end .flash-message -->
<div class="row">
	<div class="col-md-12" style="margin-bottom: 20px;">
		<div class="row">
			<form method="post" action="/admin/opinions/create" class="horizontal-form">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<div class="col-md-6">
				<input type="text" class="form-control" placeholder="Имя Фамилия" name="username" value="">
			</div>
			<div class="col-md-6">
				<input type="text" class="form-control" placeholder="Ссылка на страницу пользователя" name="user_link" value="">
			</div>
			<div class="col-md-6">
				<input type="text" class="form-control" placeholder="Ссылка на аватар пользователя" name="user_avatar" value="">
			</div>
			<div class="col-md-6">
				<input type="text" class="form-control" placeholder="Текст отзыва" name="text" value="">
			</div>
			<div class="col-md-6">
				<input type="text" class="form-control" placeholder="Ссылка на вложение" name="photo" value="">
			</div>
			<div class="col-md-6">
				<input type="text" class="form-control" placeholder="Ссылка на оригинал отзыва" name="opinion_link" value="">
			</div>
		</div>
		<div class="row">
			<div class="col-md-10"></div>
			<div class="col-md-2"><button type="submit" class="btn blue"><i class="fa fa-check"></i> Добавить отзыв</button></div>
		</div>
	</div>
	<div class="col-md-12">
		<center><h2>Добавленные отзывы</h2></center>
		<div class="row">
			<?php $__currentLoopData = $opinions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class = "col-md-12" style="padding: 20px;border: 1px dashed black;">
				<div class = "col-md-6">
					<b>Пользователь:</b>  <a href="<?php echo e($o->user_link); ?>" target="blank"><?php echo e($o->username); ?></a><br>
					<b>Тест:</b> <?php echo e($o->text); ?><br>
					<?php if(isset($o->photo)): ?><b>Прикрепил:</b> <br> <img src="<?php echo e($o->photo); ?>" width="250px"><?php endif; ?>
				</div>
				<a href="/admin/opinion/<?php echo e($o->id); ?>/delete">
				<div class="btn red pull-right">
					<i class="fa fa-times" aria-hidden="true"></i> Удалить 
				</div>
				</a>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/admin/pages/opinions.blade.php ENDPATH**/ ?>