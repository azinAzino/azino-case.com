<?php $__env->startSection('content'); ?>
<div class="top-bar">
	<h3><?php echo e(__('Last 20 Payments')); ?></h3>
</div>
<div class="portlet light bordered">
	<div class="portlet-body">
		<p id="date_filter">
			<span id="date-label-from" class="date-label"><?php echo e(__('From')); ?>: </span><input class="date_range_filter date" type="text" id="datepicker_from" />
			<span id="date-label-to" class="date-label"><?php echo e(__('To')); ?>:<input class="date_range_filter date" type="text" id="datepicker_to" />
		</p>
		<table id="paymentsTable" class="table table-striped table-bordered">
			<thead>
				<tr>
					<th>#</th>
					<th><?php echo e(__('User')); ?></th>
					<th><?php echo e(__('Amount')); ?></th>
					<th><?php echo e(__('Date')); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if(!empty($a)): ?>
				<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($b->id); ?></td>
					<td><a href="/user/<?php echo e($b->name_id); ?>" target="blank"><?php echo e($b->name); ?></a></td>
					<td><?php echo e($b->amount); ?>$</td>
					<td><?php echo e($b->timestamp); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				<tr>
					<td> <b><?php echo e(__('No data')); ?></b> </td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/admin/pages/payments.blade.php ENDPATH**/ ?>