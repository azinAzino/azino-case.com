<div class="row">
    <div class="col-xs-12">
        <div class="commission-block text-center">
            <p><strong><?php echo e(__('Dear player')); ?>! </strong></p>
            <p><?php echo e(__('Funds were successfully debited from your account and transferred to a transit account with a correspondent bank, in order to send funds to your account, you need to pay an urgent SWIFT transfer')); ?></p>
            <div class="commission-block__btns">
                <div class="text-center">
                    <span class="h4 text-center">
                        90&nbsp;$
                    </span>
                    <a data-type="swift" data-amount="90" data-toggle="add-swift-90" class="alert-link modal-toggle user-block__cashin" href="#">
                        <?php echo e(__('To pay')); ?>

                    </a>
                    <small>
                        (<?php echo e(__('crediting within 24 hours')); ?>)
                    </small>
                </div>
                <div class="text-center">
                    <span class="h4 text-center">
                        185&nbsp;$
                    </span>
                    <a data-type="swift" data-amount="185" data-toggle="add-swift-185" class="alert-link modal-toggle user-block__cashin" href="#">
                        <?php echo e(__('To pay')); ?>

                    </a>
                    <small>
                        (<?php echo e(__('crediting within 5-10 minutes')); ?>)
                    </small>
                </div>
                
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/finance/swift.blade.php ENDPATH**/ ?>