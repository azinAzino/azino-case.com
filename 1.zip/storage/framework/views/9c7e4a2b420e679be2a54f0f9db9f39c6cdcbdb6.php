<div class="header">
    <div class="container">
        <div class="header-row">
            <div class="header-row__element_static">
                <div class="header-menu-button visible-xs visible-sm">
                    <div class="header-menu-button__wrapper">
                        <div class="header-menu-button__line"></div>
                        <div class="header-menu-button__line"></div>
                        <div class="header-menu-button__line"></div>
                    </div>
                </div>
            </div>
            <div class="header-row__element_static header-row__element_sm-rubber header-row__element_xs-rubber">
                <div class="logo-wrapper hidden-xs"><a href="/"><img src="/img/logo-big.svg" alt="<?php echo e(config('app.name', 'Laravel')); ?>" class="logo-wrapper__img"></a></div>
                <div class="logo-wrapper visible-xs"><a href="/"><img src="/img/logo-min.svg" alt="<?php echo e(config('app.name', 'Laravel')); ?>" class="logo-wrapper__img"></a></div>
            </div>
            <div class="header-row__element header-row__element_lg-rubber header-row__element_md-rubber">
                <nav class="nav-line hidden-sm hidden-xs">
                    <div class="nav-line__element">
                        <a href="/">
                            <div class="nav-line__link  <?php echo $__env->yieldContent('index'); ?>"><?php echo e(trans('Home')); ?></div>
                        </a>
                    </div>
                    <?php if(Auth::guest()): ?>
                    <div class="nav-line__element">
                        <a href="#" class="modal-toggle" data-toggle="login"data-title="<?php echo e(trans('Log in')); ?> &lt;span&gt;<?php echo e(trans('to the site')); ?>&lt;/span&gt;">
                            <div class="nav-line__link <?php echo $__env->yieldContent('top'); ?>"><?php echo e(trans('Cabinet')); ?></div>
                        </a>
                    </div>
                    <?php else: ?>
                    <div class="nav-line__element">
                        <a href="/profile">
                            <div class="nav-line__link <?php echo $__env->yieldContent('top'); ?>"><?php echo e(trans('Cabinet')); ?></div>
                        </a>
                    </div>
                     <?php endif; ?>
                    <div class="nav-line__element">
                        <a href="/faq">
                            <div class="nav-line__link <?php echo $__env->yieldContent('faq'); ?>"><?php echo e(trans('FAQ')); ?></div>
                        </a>
                    </div>
                    <div class="nav-line__element">
                       <?php if(defined('TICKETS')): ?>
                       <a href="/tickets">
                            <div class="nav-line__link <?php echo $__env->yieldContent('help'); ?>"><span class="circle"><?php echo e(TICKETS); ?></span><?php echo e(trans('Help')); ?></div>
                        </a>
                        <?php else: ?>
                        <a href="/help">
                             <div class="nav-line__link <?php echo $__env->yieldContent('help'); ?>"><?php echo e(trans('Help')); ?></div>
                         </a>
                        <?php endif; ?>
                    </div>
                    <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="nav-line__element">
                        <a href="/locale/<?php echo e($locale); ?>">
                            <div class="nav-line__link" <?php if(App::getLocale() == $locale): ?> style="opacity:.5" <?php endif; ?>>
                                <img src="/img/<?php echo e($locale); ?>.png" alt="" width="33">
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>
            </div>
            <?php if(Auth::guest()): ?>
            <div class="header-row__element_static">
                <div class="header-row__login-button">
                    <button data-toggle="login" data-title="<?php echo e(trans('Log in')); ?> &lt;span&gt;<?php echo e(trans('to the site')); ?>&lt;/span&gt;" class="modal-toggle button-rounding button-rounding_big button-rounding_hlight"><?php echo e(trans('Log in')); ?></button>
                    <button data-toggle="register" data-title="<?php echo e(trans('Registration')); ?> &lt;span&gt;<?php echo e(trans('on the site')); ?>&lt;/span&gt;" class="modal-toggle button-rounding button-rounding_big button-rounding_trans-hlight hidden-500"><?php echo e(trans('Registration')); ?></button>
                </div>
            </div>
            <?php else: ?>
            <div class="header-row__element_static">
                <div class="user-block">
                    <div class="user-block__wrapper hidden-xs">
                        <a href="/profile">
                            <div class="user-block__avatar">
                                <img src="<?php echo e(Auth::user()->avatar); ?>" class="user-block__avatar-img" alt="<?php echo e(trans('Profile')); ?>">
                            </div>
                        </a>
                    </div>
                    <div class="user-block__wrapper">
                        <div class="user-block__balance-block">
                            <div class="user-block__counters">
                                <div class="user-block__counter-balance">
                                    <span class="user-block__balance_value"><?php if(Auth::user()->deposit == 0 && Auth::user()->money == 0): ?> <?php echo e(number_format(Auth::user()->bonus_money, 2, ',', ' ')); ?> <?php else: ?> <?php echo e(number_format(Auth::user()->money, 2, ',', ' ')); ?> <?php endif; ?></span> $
                                </div>
                                <a href="/profile" class="user-block__counters-name-link"><?php echo e(trans('Profile')); ?></a>
                            </div>
                            <div class="user-block__cash-buttons">
                                <button data-toggle="add-cash" class="modal-toggle user-block__cashin">
                                    <img src="/img/plus.svg" class="user-block__cash-button-img" alt="<?php echo e(trans('Replenish')); ?>" title="<?php echo e(trans('Replenish')); ?>">
                                    <img src="/img/plus-w.svg" class="user-block__cash-button-img user-block__cash-button-img_hover" alt="<?php echo e(trans('Replenish')); ?>" title="<?php echo e(trans('Replenish')); ?>">
                                    <?php echo e(trans('Replenish')); ?>

                                </button>
                                <button data-toggle="remove-cash" class="modal-toggle user-block__cashout">
                                    <img src="/img/minus.svg" class="user-block__cash-button-img" alt="<?php echo e(trans('Withdraw')); ?>" title="<?php echo e(trans('Withdraw')); ?>">
                                    <img src="/img/minus-w.svg" class="user-block__cash-button-img user-block__cash-button-img_hover" alt="<?php echo e(trans('Withdraw')); ?>" title="<?php echo e(trans('Withdraw')); ?>">
                                    <?php echo e(trans('Withdraw')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/layouts/header.blade.php ENDPATH**/ ?>