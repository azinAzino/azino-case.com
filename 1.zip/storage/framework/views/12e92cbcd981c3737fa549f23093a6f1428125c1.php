Вы успешно зарегистрировались
Ваш Логин: <?php echo e($user->username); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/mails/user_registered.blade.php ENDPATH**/ ?>