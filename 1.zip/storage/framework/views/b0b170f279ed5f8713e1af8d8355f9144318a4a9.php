<?php $__env->startSection('title'); ?>
<?php echo e(('Profile of user')); ?> - <?php echo e($user->username); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
<?php  $settings = \DB::table('settings')->where('id', 1)->first(); 
		$my_refs = \DB::table('users')->where('ref_user',$user->id)->count();
		$zarabotal = \DB::table('operations')->where('ref_user',$user->id)->where('type', 0)->where('status', 1)->sum('amount');
		if($zarabotal == '')
		{
			$zarabotal = 0;
		}
		?>
            <div class="container">
        <div class="button-line">
            <a href="#" onclick="return history.back()" class="button-line__button button-rounding button-rounding_trans-big button-rounding_trans-hlight">
            <?php echo e(('Back')); ?>

                <div class="button-line__button-icon"></div>
            </a>
        </div>
    </div>
    <div class="profile-row">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
                    <div class="profile-row__user-info-wrapper">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-12 col-md-offset-0 col-lg-12 col-lg-offset-0">
                                <div class="profile-row__user-avatar">
                                    <div class="profile-row__user-avatar-wrapper"><img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->username); ?>" class="profile-row__user-avatar-img"></div>
                                </div>
                                <div class="profile-row__user-name"><?php echo e($user->username); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                    <div class="row">
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value">
                                <?php echo e(__('Opened cases')); ?>&nbsp;<span><?php echo e($user->opened); ?></span><br>
                                <?php echo e(__('For the amount')); ?>:&nbsp;<span><?php echo e($user->profit); ?><span class="dollar yellow">$</span></span>
                                    <img src="/img/system/egg-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value profile-row__user-stat-value_alone">
                                    <?php echo e(__('Top place')); ?>:&nbsp;<span><?php echo e($usr_pos); ?></span>
                                    <img src="/img/system/position-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value">
									<?php echo e(__('Invited')); ?>:&nbsp;<span><?php echo e($my_refs); ?></span><br>
									<?php echo e(__('Earned')); ?>:&nbsp;<span><?php echo e($zarabotal); ?><span class="dollar yellow">$</span></span>
                                    <img src="/img/system/users-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="lk-block">
                        <div class="lk-block__header">
                            <div class="lk-block__header-line"></div>
							<div class="lk-block__header-text"><?php echo __('Game <span>history</span>'); ?></div>
                            <div class="lk-block__header-line"></div>
                        </div>
                        <div class="game__contains">
                            <div class="row">
								<?php if(isset($history) && !empty($history)): ?>
								<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if(isset($h->image)): ?>
								<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
									<div class="game__contains-cell game__contains-cell_none">
										
											<div class="game__contains-img-wrapper game__contains-img-wrapper_with-header">
											<div class="game__contains-header"><?php echo e(__($h->name)); ?></div>
												<div class="game__contains-egg-glow"></div><img src="<?php echo e($h->image); ?>" alt="" class="game__contains-egg-img">
											</div>
										
									</div>
								</div> 
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
                            </div>
                             <div class="button-line button-line_center <?php if(count($history) != 24): ?> hidden <?php endif; ?>">
                                <button class="button-line__button button-rounding button-rounding_trans-big button-rounding_trans-hlight" id="profile_games_more" data-user-id="<?php echo e($user->id); ?>" data-last-game="<?php echo e($last_g); ?> ">
									<?php echo e(__('Show more')); ?>

                                </button>
                            </div>
                            <div class="button-line button-line_center hidden">
								<p><?php echo e(__('User has not played any balance games yet.')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/user.blade.php ENDPATH**/ ?>