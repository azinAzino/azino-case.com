<?php $__env->startSection('title'); ?>
<?php echo e(__('Cases with money')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('index'); ?>
nav-line__link_active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="cases-line">
        <div class="container">
            <div class="row eggs-cases-row">
                <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="new-card-col col-xs-12 col-sm-4 col-md-3 col-lg-3" id="list-box - <?php echo e($c->id); ?>">
                    <a href="/cart/<?php echo e($c->id); ?> " onclick="/*$('.sound_heart')[0].play();*/">
                        <div class="new-card">
                            <img class="new-card__bg-img" src="<?php echo e($c->image); ?>" alt="" />
                            <div class="new-card__header">
                                <div class="new-card__price">
                                    <?php echo e($c->cost); ?> <span class="dollar yellow"> $</span>
                                </div>
                            </div>
                            <div class="new-card__footer">
                                <div class="new-card__name"> <?php echo e(__ ($c->name)); ?> </div>
                                <div class="new-card__content">
                                    <?php echo e(__('Win from')); ?>

                                    <span>
                                        <?php echo e($c->min); ?> <span class="dollar yellow"> $</span>
                                    </span>
                                    <?php echo e(__('to')); ?>

                                    <span>
                                        <?php echo e($c->max); ?> <span class="dollar yellow"> $</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="top-line hidden-xs">
        <div class="container">
            <div class="top-line__header">
                <div class="top-line__header-line"></div>
                <div class="top-line__header-text"><?php echo __('Top<span>10</span>'); ?></div>
                <div class="top-line__header-line"></div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $top_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="<?php if($key == 0): ?> top-line__card top-line__card_gold <?php elseif($key == 1): ?> top-line__card top-line__card_red <?php elseif($key == 2): ?> top-line__card top-line__card_blue <?php else: ?> top-line__card top-line__card_default <?php endif; ?>">
                        <a href="/user/<?php echo e($user->id); ?>">
                            <div class="top-line__position"><?php echo e($key + 1); ?></div>
                            <div class="top-line__user-ava">
                                <div class="circle-ava">
                                    <img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->username); ?>" class="circle-ava__img" />
                                </div>
                            </div>
                            <div class="top-line__user-name"><?php echo e($user->username); ?></div>
                            <div class="top-line__user-stat-block">
                                <div class="top-line__user-stat">
                                    <div class="top-line__user-stat-icon"> <img src="/img/system/egg-icon_gold.png" alt="" class="top-line__user-stat-icon-img">
                                    </div>
                                    <div class="top-line__user-stat-value"><?php echo e($user->opened); ?></div>
                                </div>
                                <div class="top-line__user-stat">
                                    <div class="top-line__user-stat-icon"> <img src="/img/system/money__icon_yellow.png" alt="" class="top-line__user-stat-icon-img"> </div>
                                    <div class="top-line__user-stat-value"> <?php echo e($user->profit); ?> <span class="dollar yellow"></span>$<span></div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="advantages-block">
        <div class="container">
            <div class="advantages-block__header">
                <div class="advantages-block__header-line"></div>
                <div class="advantages-block__header-text"><?php echo __('Our <span> advantages </span>'); ?></div>
                <div class="advantages-block__header-line"></div>
            </div>
            <div class="advantages-block__advantages-wrapper">
                <div class="advantages-block__icon-wrapper hidden-xs">
                    <div class="advantages-block__icon-glow"></div>
                    <div class="advantages-block__icon-block"><img src="/img/system/rocket.png" alt="" class="advantages-block__icon" /></div>
                </div>
                <div class="advantages">
                    <div class="advantages__header"><?php echo e(__('Quick payouts')); ?></div>
                    <div class="advantages__text"><?php echo e(__('The minimum payout time is only 1 minute! All payments are automatic. You no longer need to wait 24 hours for your winnings! The minimum amount for withdrawal is only 100 rubles! All payments are made without additional fees! ')); ?></div>
                </div> 
            </div>
            <div class="advantages-block__advantages-wrapper">
                <div class="advantages-block__icon-wrapper hidden-xs">
                    <div class="advantages-block__icon-glow"></div>
                    <div class="advantages-block__icon-block"><img src="/img/system/wifi.png" alt="" class="advantages-block__icon"></div>
                </div>
                <div class="advantages">
                    <div class="advantages__header"> <?php echo e(__('Security')); ?></div>
                    <div class="advantages__text"><?php echo e(__('All data is secure and transmitted over SSL encrypted protocol, making your account completely safe.')); ?></div>
                </div>
            </div>
            <div class="advantages-block__advantages-wrapper">
                <div class="advantages-block__icon-wrapper hidden-xs">
                    <div class="advantages-block__icon-glow"></div>
                    <div class="advantages-block__icon-block"><img src="/img/system/happy-man.png" alt="" class="advantages-block__icon"></div>
                </div>
                <div class="advantages">
                    <div class="advantages__header"><?php echo e(__('Openness and Security')); ?></div>
                    <div class="advantages__text"><?php echo e(__('All games are displayed in a live stream. Player profiles are open along with the history of all games! In order to prevent fraud, we do not publish confidential user information!')); ?></div>
                </div>    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<?php if(Auth::guest () && isset ($utm_name) && isset ($utm_avatar)): ?>
<!-- Welcome modal -->
<div id="hi-modal" class="modal-window modal-window_size_s modal-window_color_default" style="display: none; margin-top: -154.5px; margin-left: -260px;">
        <div class="modal-window__wrapper">
                <div class="modal-window__header-wrapper">
                        <div class="modal-window__header">
                                <?php echo e(__('Hello!')); ?>

                            </div>
                        <button class="modal-window__close-button">
                                <img src="/img/close-mobile-menu.svg" alt="close" class="modal-window__close-button-img modal-window__close-button-img_blur">
                                <img src="/img/close-mobile-menu-hover.svg" alt="close" class="modal-window__close-button-img modal-window__close-button-img_hover">
                            </button>
                    </div>
                <div class="modal-window__content-wrapper">
                        <div class="row">
                                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                        <div class="modal-window__user-ava modal-window__element circle-ava">
                        <img src="<?php echo e($utm_avatar); ?>" alt="" class="circle-ava__img">
                    </div>
                                    </div>
                                <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                                        <div class="modal-window__element text-block text-block_fs_mb"><?php echo e(__('Cash bonus from')); ?> <?php echo e($utm_name); ?> </div>
                                        <div class="modal-window__element text-block text-block_color_gray"> <?php echo e(__('To get a bonus go through a simple registration!')); ?> </div>
                                        <div class="modal-window__element">
                        <button data-toggle="login" data-title="Register <span> on the site </span>" class="modal-toggle modal-window__button button-rounding button-rounding_big button-rounding_light"> <?php echo e(__('Sign up')); ?> </button>
                                            </div>
                                    </div>
                            </div>
                    </div>
            </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foo_index'); ?>
footer__nav-link_active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_index'); ?>
header-menu__link_active
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/index.blade.php ENDPATH**/ ?>