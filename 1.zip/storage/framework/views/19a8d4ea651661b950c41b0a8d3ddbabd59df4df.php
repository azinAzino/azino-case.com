<?php $__env->startSection('title'); ?>
<?php echo e(__('Profile')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('banner'); ?>
<a href="/bonus" class=" bonus-banner bonus-banner_auth  ">
    <div class="hidden-xs bonus-banner__button"><?php echo e(__('Read')); ?></div>
</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <?php $settings = \DB::table('settings')->where('id', 1)->first();
    $my_refs = \DB::table('users')->where('ref_user', Auth::user()->id)->count();
    $zarabotal = \DB::table('operations')->where('ref_user', Auth::user()->id)->where('type', 0)->where('status', 1)->sum('amount');
    if ($zarabotal == '') {
        $zarabotal = 0;
    }
    ?>
    <div class="profile-row">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
                    <div class="profile-row__user-info-wrapper">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
                                <div class="profile-row__user-avatar">
                                    <div class="profile-row__user-avatar-wrapper">
                                        <img src="<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->userame); ?>" class="profile-row__user-avatar-img">
                                    </div>
                                </div>
                                <div class="profile-row__user-name"><?php echo e(Auth::user()->username); ?></div>
                                <div class="profile-row__balance">
                                    <img src="/img/system/money__icon_yellow.png" alt="" class="profile-row__balance-img">
                                    <?php echo e(Auth::user()->money); ?><span class="dollar yellow">$</span>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
                                <div class="profile-row__button-line button-line">
                                    <button class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_hlight modal-toggle" data-toggle="add-cash"><?php echo e(__('Top up balance')); ?></button>
                                    <button class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_trans-hlight modal-toggle" data-toggle="remove-cash"><?php echo e(__('Withdraw funds')); ?></button>
                                    <a href="/logout" onclick="return confirm(window.__('Are you sure you want to sign out?'))" class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_trans-dark"><?php echo e(__('Logout')); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                    <?php if(isset($show_swift) && $show_swift): ?> <?php echo $__env->make('finance.swift', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
                    <?php if(isset($show_tax) && $show_tax): ?> <?php echo $__env->make('finance.tax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
                    <div class="row">
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value">
                                    <?php echo e(__('Opened cases')); ?>:&nbsp;<span><?php echo e(Auth::user()->opened); ?></span><br>
                                    <?php echo e(__('For the amount')); ?>:&nbsp;<span><?php echo e(Auth::user()->profit); ?><span class="dollar yellow">$</span></span>
                                    <img src="/img/system/egg-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value profile-row__user-stat-value_alone">
                                    <?php echo e(__('Top place')); ?>:&nbsp;<span><?php echo e($usr_pos); ?></span>
                                    <img src="/img/system/position-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value">
                                    <?php echo e(__('Invited')); ?>:&nbsp;<span><?php echo e($my_refs); ?></span><br>
                                    <?php echo e(__('Earned')); ?>:&nbsp;<span><?php echo e($zarabotal); ?><span class="dollar yellow">$</span></span>
                                    <img src="/img/system/users-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="lk-tabs button-line">
                        <a href="/profile" class="lk-tabs__lk-tab button-line__button button-rounding button-rounding_med button-rounding_trans-dark">
                            <?php echo e(__('Game history')); ?>

                        </a>
                        
                        <a href="/profile/finance" class="lk-tabs__lk-tab button-line__button button-rounding button-rounding_med button-rounding_dark button-rounding_active">
                            <?php echo e(__('Finance')); ?>

                        </a>
                    </div>
                    <div id="finance" class="lk-block finance">
                        <div class="lk-block__header">
                            <div class="lk-block__header-line"></div>
                            <div class="lk-block__header-text"><?php echo __('Financial <span>operations</span>'); ?></div>
                            <div class="lk-block__header-line"></div>
                        </div>
                        <div class="nav-line finance__nav-line">
                            <div class="nav-line__element finance__nav-element">
                                <div data-toggleup="" data-toggledown=".finance__tr_cashout, .finance__tr_cashin, .finance__tr_bonus, .finance__tr_affiliate" class="nav-line__link finance__filter-button nav-line__link_active">
                                    <?php echo e(__('All operations')); ?>

                                </div>
                            </div>
                            <div class="nav-line__element finance__nav-element">
                                <div data-toggleup=".finance__tr_cashout, .finance__tr_affiliate" data-toggledown=".finance__tr_cashin, .finance__tr_bonus" class="nav-line__link finance__filter-button">
                                    <?php echo e(__('Recharge')); ?>

                                </div>
                            </div>
                            <div class="nav-line__element finance__nav-element">
                                <div data-toggleup=".finance__tr_cashin, .finance__tr_bonus, .finance__tr_affiliate" data-toggledown=".finance__tr_cashout" class="nav-line__link finance__filter-button">
                                    <?php echo e(__('Conclusions')); ?>

                                </div>
                            </div>
                            
                        </div>
                        <div class="table-col">
                            <table class="finance__table main-table">
                                <thead>
                                    <tr>
                                        <th class="main-table__th main-table__th_center">№</th>
                                        <th class="main-table__th main-table__th_left"><?php echo e(__('Type of transaction')); ?></th>
                                        <th class="main-table__th main-table__th_left"><?php echo e(__('Title')); ?></th>
                                        <th class="main-table__th main-table__th_center"><?php echo e(__('Amount')); ?></th>
                                        <th class="main-table__th main-table__th_center"><?php echo e(__('Status')); ?></th>
                                        <th class="main-table__th main-table__th_center"><?php echo e(__('Date')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="main-table__tbody-tr finance__tr <?php if($o->type == 0): ?> finance__tr_cashin <?php elseif($o->type == 1): ?> finance__tr_cashout <?php elseif($o->type == 3): ?> finance__tr_affiliate <?php elseif($o->type == 4): ?> finance__tr_bonus <?php endif; ?>" style="">
                                        <td class="main-table__td main-table__td_reg main-table__th_center"><?php echo e($o->id); ?></td>
                                        <td class="main-table__td main-table__td_reg main-table__td_left">
                                            <div class="finance__type"><?php if($o->type == 0): ?> <?php echo e(__('Balance replenishment')); ?><?php elseif($o->type == 1): ?> <?php echo e(__('Withdraw fund')); ?> <?php elseif($o->type == 2): ?> <?php echo e(__('Bonus')); ?> <?php elseif($o->type == 3): ?> <?php echo e(__('Affiliate accrual')); ?> <?php elseif($o->type == 4): ?> <?php echo e(__('Bonus accrual')); ?><?php endif; ?></div>
                                        </td>
                                        <td class="main-table__td main-table__td_reg main-table__td_left"><?php if($o->type == 0): ?> <?php echo e(__('Balance replenishment through the payment system')); ?> <?php elseif($o->type == 1): ?> <?php echo e(__('Withdraw funds to the wallet')); ?> <?php echo e($o->koshelek); ?> <?php elseif($o->type == 3): ?> <?php echo e(__('Refill your account with a referral')); ?> <?php elseif($o->type == 4): ?> <?php echo e(__('Bonus accrual for registration')); ?> <?php endif; ?></td>
                                        <td class="main-table__td main-table__td_reg main-table__td_center"><?php echo e($o->amount); ?><span class="dollar dollar_white">$</span></td>
                                        <td class="main-table__td main-table__td_reg main-table__td_center">
                                            <div class="finance__status finance__status_expects"><?php if($o->status == 0): ?> <?php echo e(__('Wating')); ?> <?php elseif($o->status == 1): ?> <?php echo e(__('Completed')); ?> <?php elseif($o->status == 3): ?> <?php echo e(__('Rejected')); ?> <?php endif; ?></div>
                                        </td>
                                        <td class="main-table__td main-table__td_reg main-table__td_center"><?php echo e($o->timestamp); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="button-line button-line_center hidden">
                                <button class="button-line__button button-rounding button-rounding_trans-big button-rounding_trans-hlight" id="profile_finance_more" data-last-transaction="">
                                    <?php echo e(__('More')); ?>

                                </button>
                            </div>
                            <div class="button-line button-line_center hidden">
                                <p><?php echo e(__('You have no financial transactions yet.')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/finance.blade.php ENDPATH**/ ?>