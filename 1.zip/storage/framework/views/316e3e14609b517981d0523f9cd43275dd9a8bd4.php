<?php $__env->startSection('content'); ?>
<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<a href="/admin">Главная</a>
			<i class="fa fa-circle"></i>
		</li>
		<li>
			<span>Выводы</span>
		</li>
	</ul>
</div>

<h1 class="page-title"> Выводы пользователей </h1>

<div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="portlet light bordered">
			<div class="portlet-body">
				<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>ID</th>
							<th>Пользователь</th>
							<th>Система</th>
							<th>Кошелек</th>
							<th>Сумма</th>
							<th>Время</th>
							<th>Статус</th>
							<th>Редактировать</th>
						</tr>
					</thead>
					<tbody>
					<?php if(isset($withdrows)): ?>
						<?php $__currentLoopData = $withdrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td style="vertical-align: middle;"><?php echo e($withdrow->id); ?></td>
							<td style="vertical-align: middle;"><a href="https://vk.com/<?php echo e($withdrow->user->login); ?>" target="_blank"><?php echo e($withdrow->user->username); ?></a> | <div data-toggle="modal" data-target="#user_edit" href="/admin/user/<?php echo e($withdrow->user->id); ?>/edit" style="display: inline-block;
																									cursor: pointer;">Инфо</div></td>
							<td style="vertical-align: middle;"><?php if(isset($withdrow->koshelek)): ?>
																<?php if($withdrow->koshelek == 'yandex'): ?>
																<center><img src="/img/icons/yandex.png" width="70px" alt = 'Yandex Money'></center>
																<?php elseif($withdrow->koshelek == 'qiwi'): ?>
																<center><img src="/img/icons/qiwi.png" width="30px" alt = 'Qiwi Visa Wallet'></center>
																<?php elseif($withdrow->koshelek == 'payeer'): ?>
																<center><img src="/img/icons/payeer.png" width="70px" alt = 'Qiwi Visa Wallet'></center>
																<?php else: ?>
																<center><img src="/img/icons/webmoney.png" width="70px" alt = 'WebMoney'></center>
																<?php endif; ?></td>
																<?php endif; ?>
							<td style="vertical-align: middle;"><?php echo e($withdrow->nomer); ?></td>
							<td style="vertical-align: middle;"><?php echo e($withdrow->amount); ?></td>
							<td style="vertical-align: middle;"><?php echo e($withdrow->dfh); ?></td>
																<?php if(isset($withdrow->status)): ?>
							<td style="vertical-align: middle;"><?php if($withdrow->status == 0): ?>
																<div class="btn green btn-sm">Ожидает</div>
																<?php elseif($withdrow->status == 1): ?>
																<div class="btn orange btn-sm">Выплачено</div>
																<?php elseif($withdrow->status == 2): ?>
																<div class="btn red btn-sm">Отказано</div>
																<?php endif; ?></td>
																<?php endif; ?>
							<td style="vertical-align: middle;"><?php if(isset($withdrow->status) && isset($withdrow->id)): ?> <?php if($withdrow->status == 0): ?><a class="btn blue btn-sm" data-toggle="modal" data-target="#usr_edit" href="/admin/withdraw/<?php echo e($withdrow->id); ?>/edit">Редактировать</a><?php endif; ?> <?php endif; ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php if(!empty($withdrows)): ?>
<div class="modal fade" id="usr_edit" tabindex="-1" role="basic" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<?php if(isset($withdrow)): ?>
			<?php echo $__env->make('admin.includes.modal_withdrows', ['user' => $withdrow], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php else: ?>
			<?php endif; ?>
		</div>
	</div>
</div>
<div class="modal fade" id="user_edit" tabindex="-1" role="basic" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<?php echo $__env->make('admin.includes.modal_users', ['user' => $withdrow->user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/admin/pages/withdraw.blade.php ENDPATH**/ ?>