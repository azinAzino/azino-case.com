<?php $__env->startSection('name'); ?>
<?php echo e(__('Help')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<?php echo e(__('Help')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('help'); ?>
nav-line__link_active
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="HelpLg">
		<div class="HelpLg__wrapper container">
			<div class="HelpLg__header"><?php echo e(__('Help')); ?></div>
			<div class="HelpLg__button-row row">
				<div class="Help__button-col col-md-4 col-sm-6 col-xs-12">
					<a href="mailto:info@azino-case.com" target="_blank">
						<div class="HelpButton">
							<div class="HelpButton__img-wrapper"> <img class="HelpButton__img" src="/img/system/1.png" alt="info@azino-case.com"> </div>
							<div class="HelpButton__text">
								<div class="HelpButton__title"> <?php echo e(__('For any questions')); ?> </div>
								<div class="HelpButton__link-wrapper"> <span class="HelpButton__link"> info@azino-case.com </span>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="Help__button-col col-md-4 col-sm-6 col-xs-12">
					<?php if(Auth::guest()): ?>
					<a href="#" class="modal-toggle" data-toggle="login" data-title="<?php echo e(trans('Log in')); ?> &lt;span&gt;<?php echo e(trans('to the site')); ?>&lt;/span&gt;">
						<div class="HelpButton">
							<div class="HelpButton__img-wrapper"> <img class="HelpButton__img" src="/img/system/2.png" alt="info@azino-case.com"> </div>
							<div class="HelpButton__text">
								<div class="HelpButton__title"> <?php echo e(__('Tech Support')); ?> </div>
								<div class="HelpButton__link-wrapper"> <span class="HelpButton__link"> <?php echo e(__('Write')); ?> </span>
								</div>
							</div>
						</div>
					</a>
					<?php else: ?>
					<a href="/tickets">
						<div class="HelpButton">
							<div class="HelpButton__img-wrapper"> <img class="HelpButton__img" src="/img/system/2.png" alt="info@azino-case.com"> </div>
							<div class="HelpButton__text">
								<div class="HelpButton__title"> <?php echo e(__('Tech Support')); ?> </div>
								<div class="HelpButton__link-wrapper"> <span class="HelpButton__link"> <?php echo e(__('Write')); ?> </span>
								</div>
							</div>
						</div>
					</a>
					<?php endif; ?>
				</div>
				<div class="Help__button-col col-md-4 col-sm-6 col-xs-12">
					<a href="mailto:reklama@azino-case.com" target="_blank">
						<div class="HelpButton">
							<div class="HelpButton__img-wrapper"> <img class="HelpButton__img" src="/img/system/3.png" alt=" reklama@azino-case.com"> </div>
							<div class="HelpButton__text">
								<div class="HelpButton__title"> <?php echo e(__('Advertising Suggestions')); ?> </div>
								<div class="HelpButton__link-wrapper"> <span class="HelpButton__link">  reklama@azino-case.com </span>
								</div>
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foo_help'); ?>
footer__nav-link_active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_help'); ?>
Title-menu__link_active
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/help.blade.php ENDPATH**/ ?>