<script>
	$("#range_1").ionRangeSlider({
		type: "single",
		min: 0.1,
		max: 100,
		step: 0.1
	});
</script>
<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	<h4 class="modal-title"><?php echo e(trans('Edit item')); ?></h4>
</div>
<form method="post" action="/admin/item/update" class="horizontal-form" id="save">
<div class="modal-body">
	<input name="id" value="<?php echo e($item->id); ?>" type="hidden">
	<input name="card" value="<?php echo e($item->card); ?>" type="hidden">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<div class="form-body">
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Price')); ?></label>
					<input type="text" class="form-control" name="cost" value="<?php echo e($item->cost); ?>">
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label">Тип</label>
					<select class="form-control" tabindex="1" name="type" value="<?php echo e($item->type); ?>">
						<option value="0" <?php if($item->type == '0'): ?> selected <?php endif; ?>>=<?php echo e(trans('Dropdown')); ?></option>
						<option value="1" <?php if($item->type == '1'): ?> selected <?php endif; ?>>=<?php echo e(trans('Not dropdown')); ?></option>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group text-center">
					<label class="control-label">Путь к картинке</label>
					<input type="text" class="form-control" name="img" placeholder="<?php echo e(trans('Path to picture')); ?>: '/style/coin-100.svg" value="<?php echo e($item->image); ?>">
				</div>
			</div>
		</div>
	</div>
	
</div>
<div class="modal-footer">
	<button type="button" class="btn dark btn-outline" data-dismiss="modal"><?php echo e(trans('Close')); ?></button>
	<button type="submit" class="btn green"><i class="fa fa-check"></i> <?php echo e(trans('Save')); ?></button>
</div>
</form><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/admin/includes/modal_item_edit.blade.php ENDPATH**/ ?>