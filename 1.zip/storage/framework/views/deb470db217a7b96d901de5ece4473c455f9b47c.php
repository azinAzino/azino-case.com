<?php $__env->startSection('page', trans('ticketit::admin.administrator-create-title')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('ticketit::shared.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h2><?php echo e(trans('ticketit::admin.administrator-create-title')); ?></h2>
        </div>
        <?php if($users->isEmpty()): ?>
            <h3 class="text-center"><?php echo e(trans('ticketit::admin.administrator-create-no-users')); ?></h3>
        <?php else: ?>
            <?php echo CollectiveForm::open(['route'=> $setting->grab('admin_route').'.administrator.store', 'method' => 'POST', 'class' => 'form-horizontal']); ?>

            <div class="panel-body">
                <?php echo e(trans('ticketit::admin.administrator-create-select-user')); ?>

            </div>
            <table class="table table-hover">
                <tfoot>
                    <tr>
                        <td class="text-center">
                            <?php echo link_to_route($setting->grab('admin_route').'.administrator.index', trans('ticketit::admin.btn-back'), null, ['class' => 'btn btn-default']); ?>

                            <?php echo CollectiveForm::submit(trans('ticketit::admin.btn-submit'), ['class' => 'btn btn-primary']); ?>

                        </td>
                    </tr>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="checkbox">
                                <label>
                                    <input name="administrators[]" type="checkbox" value="<?php echo e($user->id); ?>" <?php echo $user->ticketit_admin ? "checked" : ""; ?>> <?php echo e($user->name); ?>

                                </label>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo CollectiveForm::close(); ?>

        <?php endif; ?>
    </div>
    <?php echo $users->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($master, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/vendor/kordy/ticketit/src/Views/bootstrap3/admin/administrator/create.blade.php ENDPATH**/ ?>