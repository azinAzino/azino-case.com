
<!--
<a href="http://www.free-kassa.ru/"><img src="http://www.free-kassa.ru/img/fk_btn/14.png"></a>
 -->

<script src="http://azino-case.com:3000/socket.io/socket.io.js"></script>
<script data-cfasync="false" src="/cdn-cgi/scripts/af2821b0/cloudflare-static/email-decode.min.js"></script><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>