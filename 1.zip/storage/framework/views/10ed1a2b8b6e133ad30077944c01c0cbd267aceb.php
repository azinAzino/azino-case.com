<?php $__env->startSection('title'); ?>
<?php echo e(__('Your profile')); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="container">
    <?php $settings = \DB::table('settings')->where('id', 1)->first();
    $my_refs = \DB::table('users')->where('ref_user', Auth::user()->id)->count();
    $zarabotal = \DB::table('operations')->where('ref_user', Auth::user()->id)->where('type', 0)->where('status', 1)->sum('amount');
    if ($zarabotal == '') {
        $zarabotal = 0;
    }
    ?>
    <div class="profile-row">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
                    <div class="profile-row__user-info-wrapper">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
                                <div class="profile-row__user-avatar">
                                    <div class="profile-row__user-avatar-wrapper">
                                        <img src="<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->userame); ?>" class="profile-row__user-avatar-img">
                                    </div>
                                </div>
                                <div class="profile-row__user-name"><?php echo e(Auth::user()->username); ?></div>
                                <div class="profile-row__balance">
                                    <img src="/img/system/money__icon_yellow.png" alt="" class="profile-row__balance-img">
                                    <?php echo e(Auth::user()->money); ?><span class="dollar yellow">$</span>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
                                <div class="profile-row__button-line button-line">
                                    <button class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_hlight modal-toggle" data-toggle="add-cash"><?php echo e(__('Refill balance')); ?></button>
                                    <button class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_trans-hlight modal-toggle" data-toggle="remove-cash"><?php echo e(__('Withdraw funds')); ?></button>
                                    <a href="/logout" onclick="return confirm(window.__('Are you sure you want to sign out?'))" class="profile-row__button button-line__button button-rounding button-rounding_big button-rounding_small button-rounding_trans-dark"><?php echo e(__('Logout')); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                    <?php if(isset($show_swift) && $show_swift): ?> <?php echo $__env->make('finance.swift', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
                    <?php if(isset($show_tax) && $show_tax): ?> <?php echo $__env->make('finance.tax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
                    <div class="row">
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value">
                                <?php echo e(__('Opened cases:')); ?> <span><?php echo e(Auth::user()->opened); ?></span><br>
                                <?php echo e(__('For the amount of')); ?> <span><?php echo e(Auth::user()->profit); ?><span class="dollar yellow">$</span></span>
                                    <img src="/img/system/egg-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value profile-row__user-stat-value_alone">
                                <?php echo e(__('Top position:')); ?> <span><?php echo e($usr_pos); ?></span>
                                    <img src="/img/system/position-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="profile-row__user-stat-block">
                                <div class="profile-row__user-stat-value">
                                <?php echo e(__('Invited:')); ?>  <span><?php echo e($my_refs); ?></span><br>
                                <?php echo e(__('Earned:')); ?> <span><?php echo e($zarabotal*($settings->ref_percent/100)); ?><span class="dollar yellow">$</span></span>
                                    <img src="/img/system/users-icon_64.png" alt="" class="profile-row__user-stat-img">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="lk-tabs button-line">
                        <a href="/profile" class="lk-tabs__lk-tab button-line__button button-rounding button-rounding_med button-rounding_trans-dark">
                        <?php echo e(__('Game history')); ?>

                        </a>
                        <a href="/profile/partner" class="lk-tabs__lk-tab button-line__button button-rounding button-rounding_med button-rounding_dark button-rounding_active">
                        <?php echo e(__('Affiliate program')); ?> 
                        </a>
                        <a href="/profile/finance" class="lk-tabs__lk-tab button-line__button button-rounding button-rounding_med button-rounding_trans-dark">
                        <?php echo e(__('Finance')); ?> 
                        </a>
                    </div>
                    <div class="lk-block">
                        <div class="lk-block__header">
                            <div class="lk-block__header-line"></div>
                            <div class="lk-block__header-text"><?php echo __('Affiliate <span> program </span>'); ?></div>
                            <div class="lk-block__header-line"></div>
                        </div>
                        <div class="profile-row__user-affiliate-line">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="profile-row__user-affiliate-block">
                                        <div class="profile-row__user-affiliate-header text-block text-block_fs_m text-block_tf_up text-block_fw_bold">
                                        <?php echo __('Invite your friends and <span> earn'); ?> <?php echo e($settings-> ref_percent); ?>% <?php echo __('</span> from all replenishment!'); ?>

                                        </div>
                                        <div class="profile-row__user-affiliate-header-text text-block"><?php echo e(__('Send your unique link to friends and get')); ?> <?php echo e($settings->ref_percent); ?>% <?php echo e(__('from each balance top-up by a friend! For example: if your friend tops up his balance by $100 - we will charge')); ?> $<?php echo e(100*($settings->ref_percent/100)); ?> <?php echo e(__('to your account!')); ?></div>
                                        <div class="profile-row__user-affiliate-input input-block">
                                            <?php if(Auth::user()->ref_link != 'none'): ?>
                                            <input value="<?php echo e(Auth::user()->ref_link); ?>" readonly="readonly" class="input-block__input input-block__input_size_full">
                                            <?php else: ?>
                                            <a href="/profile/partner/get-link" style="margin-top: 10px" id="get-partner-link" class="button-rounding button-rounding_big button-rounding_long button-rounding_hlight"><?php echo e(__('Get affiliate link')); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="faq-block">
                            <div class="faq-block__block">
                                <div class="faq-block__header text-block"><?php echo e(__('Questions and answers:')); ?></div>
                                <div class="faq-block__question text-block text-block_fs_m text-block_fw_bold text-block_color_yellow">
                                <?php echo e(__('What do my friends get when registering via my link?')); ?>

                                </div>
                                <div class="faq-block__answer text-block"><?php echo e(__('Everyone who signs up for your link will receive 1000 bonus rubles!')); ?></div>
                            </div>
                            <div class="faq-block__block">
                                <div class="faq-block__question text-block text-block_fs_m text-block_fw_bold text-block_color_yellow">
                                <?php echo e(__('Where can I distribute an affiliate link?')); ?>

                                </div>
                                <div class="faq-block__answer text-block"><?php echo e(__('You can send it in a personal message to your friends or put it in the video description on Youtube about our site. We do not limit the distribution of affiliate links, except in cases of SPAM. In case of detection of spam mailings with affiliate link we can block your account.')); ?></div>
                            </div>
                            <div class="faq-block__block">
                                <div class="faq-block__question text-block text-block_fs_m text-block_fw_bold text-block_color_yellow">
                                <?php echo e(__('How are affiliate rewards paid?')); ?>

                                </div>
                                <div class="faq-block__answer text-block"><?php echo e(__('All affiliate deductions are credited to your balance. You can withdraw earned money at any time.')); ?></div>
                            </div>
                        </div>
                        <div class="lk-block__subheader"><?php echo e(__('Attracted Players:')); ?></div>
                        <div class="partner-list">
                            <div class="row">
                                <div class="table-col col-xs-12">
                                    <table class="partner-list__table main-table">
                                        <thead>
                                            <tr>
                                                <th class="main-table__th main-table__th_left"><?php echo e(__('Gamer')); ?></th>
                                                <th class="main-table__th main-table__th_center"><?php echo e(__('Replenishment')); ?></th>
                                                <th class="main-table__th main-table__th_center"><?php echo e(__('Deduction')); ?></th>
                                                <th class="main-table__th main-table__th_center"><?php echo e(__('Date')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $referals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th class="main-table__th main-table__th_left"><?php echo e($r->username); ?></th>
                                                <th class="main-table__th main-table__th_center"><?php echo e($r->deposit); ?></th>
                                                <th class="main-table__th main-table__th_center"><?php echo e($settings->ref_percent); ?>%</th>
                                                <th class="main-table__th main-table__th_center"><?php echo e($r->updated_at); ?></th>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <div class="button-line button-line_center hidden">
                                        <button class="button-line__button button-rounding button-rounding_trans-big button-rounding_trans-hlight" id="profile_referrals_more" data-last-user="0">
                                        <?php echo e(__('Show more')); ?>

                                        </button>
                                    </div>
                                    <div class="button-line button-line_center <?php if(count($referals) > 0): ?> hidden <?php endif; ?>">
                                        <p><?php echo e(__('You have no players involved yet.')); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/pages/partner.blade.php ENDPATH**/ ?>