<script>
	$("#range_1").ionRangeSlider({
		type: "single",
		min: 0,
		max: 100,
		step: 10,
	});
</script>
<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
	<h4 class="modal-title"><?php echo e($user->username); ?></h4>
</div>
<form method="post" action="/admin/user/save" class="horizontal-form" id="save">
<div class="modal-body">
	<div class="row">
		<div class="col-md-12">
			<a href="https://vk.com/<?php echo e($user->login); ?>" target="_blank"><img style="width: 150px;margin: 0 auto;border-radius: 50% !important;display: block;margin-bottom: 15px;" src="<?php echo e($user->avatar); ?>" /></a>
		</div>
	</div>
	
	<input name="id" value="<?php echo e($user->id); ?>" type="hidden">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<div class="form-body">
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Name Second name')); ?></label>
					<input type="text" class="form-control" name="name" value="<?php echo e($user->username); ?>" readonly="readonly">
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Balance')); ?></label>
					<input type="number" class="form-control" name="money" value="<?php echo e($user->money); ?>" onchange="if (this.value < 0) this.value=0">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Admin')); ?></label>
					<select class="form-control" tabindex="1" name="is_admin" value="<?php echo e($user->is_admin); ?>">
						<option value="1" <?php if($user->is_admin == 1): ?> selected <?php endif; ?>><?php echo e(trans('Yes')); ?></option>
						<option value="0" <?php if($user->is_admin == 0): ?> selected <?php endif; ?>><?php echo e(trans('No')); ?></option>
					</select>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label">Ютубер</label>
					<select class="form-control" tabindex="1" name="is_yt" value="<?php echo e($user->is_yt); ?>">
						<option value="1" <?php if($user->is_yt == 1): ?> selected <?php endif; ?>><?php echo e(trans('Yes')); ?></option>
						<option value="0" <?php if($user->is_yt == 0): ?> selected <?php endif; ?>><?php echo e(trans('No')); ?></option>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Bonus balance')); ?></label>
					<input type="number" class="form-control" name="bonus_money" value="<?php echo e($user->bonus_money); ?>" onchange="if (this.value < 0) this.value=0">
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Referal link')); ?></label>
					<input type="text" class="form-control" name="ref_link" value="<?php echo e($user->ref_link); ?>">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Opened cases')); ?></label>
					<input type="number" class="form-control" name="opened" value="<?php echo e($user->opened); ?>" onchange="if (this.value < 0) this.value=0">
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Amount')); ?></label>
					<input type="number" class="form-control" name="deposit" value="<?php echo e($user->deposit); ?>" onchange="if (this.value < 0) this.value=0">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">	
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Replenished the amount')); ?>: </label>
					<input type="text" class="form-control" value="<?php echo e($user->payed); ?> $" readonly="readonly">
				</div>
			</div>
			<div class="col-md-4">	
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Withdrew on the amount')); ?>: </label>
					<input type="text" class="form-control" value="<?php echo e($user->with); ?> $" readonly="readonly">
				</div>
			</div>
			<div class="col-md-4">	
				<div class="form-group">
					<label class="control-label"><?php echo e(trans('Pending Payout')); ?>: </label>
					<input type="text" class="form-control" value="<?php echo e($user->with0); ?> $" readonly="readonly">
				</div>
			</div>
		</div>
	</div>
	
</div>
<div class="modal-footer">
	<button type="button" class="btn dark btn-outline" data-dismiss="modal"><?php echo e(trans('Close')); ?></button>
	<button type="submit" class="btn green"><i class="fa fa-check"></i> <?php echo e(trans('Save')); ?></button>
</div>
</form><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/admin/includes/modal_users.blade.php ENDPATH**/ ?>