
<!--header menu-->
<div class="header-menu-layout"></div>
<!--header menu layout-->
<div class="header-menu">
    <div class="header-menu__logo-line"><img src="/img/logo-big.svg" alt="" class="header-menu__logo-img"></div>
    <div class="header-menu__close-button">
        <img src="/img/close-mobile-menu.svg" alt="" class="header-menu__close-button-img">
        <img src="/img/close-mobile-menu-hover.svg" alt="" class="header-menu__close-button-img header-menu__close-button-img_hover">
    </div>
    <div class="header-menu__link-line">
        <a href="/">
            <div class="header-menu__link <?php echo $__env->yieldContent('index'); ?>"><?php echo e(trans('Home')); ?></div>
        </a>
    </div>
    <?php if(Auth::guest()): ?>
    <div class="header-menu__link-line">
        <a href="#" class="modal-toggle header-menu__close2-button" data-toggle="login"data-title="<?php echo e(trans('Log in')); ?> &lt;span&gt;<?php echo e(trans('to the site')); ?>&lt;/span&gt;">
            <div class="header-menu__link <?php echo $__env->yieldContent('top'); ?>"><?php echo e(trans('Cabinet')); ?></div>
        </a>
    </div>
    <?php else: ?>
    <div class="header-menu__link-line">
        <a href="/profile">
            <div class="header-menu__link <?php echo $__env->yieldContent('top'); ?>"><?php echo e(trans('Cabinet')); ?></div>
        </a>
    </div>
    <?php endif; ?>
    <div class="header-menu__link-line">
        <a href="/faq">
            <div class="header-menu__link <?php echo $__env->yieldContent('faq'); ?>"><?php echo e(trans('FAQ')); ?></div>
        </a>
    </div>
    <div class="header-menu__link-line">
        <?php if(defined('TICKETS')): ?>
        <a href="/tickets"><div class="header-menu__link <?php echo $__env->yieldContent('help'); ?>"><span class="circle"><?php echo e(TICKETS); ?></span><?php echo e(trans('Help')); ?></a></div>
        <?php else: ?>
        <a href="/help"><div class="header-menu__link <?php echo $__env->yieldContent('help'); ?>"><?php echo e(trans('Help')); ?></div></a>
        <?php endif; ?>
    </div>
    <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="header-menu__link-line">
        <a href="/locale/<?php echo e($locale); ?>">
            <div class="header-menu__link" <?php if(App::getLocale() == $locale): ?> style="opacity:.5" <?php endif; ?>>
                <img src="/img/<?php echo e($locale); ?>.png" alt="" width="33">
            </div>
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/layouts/header/menu.blade.php ENDPATH**/ ?>