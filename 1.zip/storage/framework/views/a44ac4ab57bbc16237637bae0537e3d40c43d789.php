<div class="footer-wrapper">
    <div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 col-md-3 col-lg-3 hidden-xs">
                <div class="footer__copyright-block">
                    <div class="footer__copyright text-block text-block_fs_m">© 2017 &mdash; 2020</div>
                    <div class="footer__mini-description text-block text-block_color_gray text-block_fs_m"><?php echo e(trans('Cases with money')); ?>!</div>
                    <div class="footer__terms text-block text-block_color_gray text-block_fs_m"><?php echo e(trans('Write to us')); ?>: <a href="email:info@azino-case.com"><span class="text-block__link">info@azino-case.com</span></a></div>
                    <div class="footer__terms text-block text-block_color_gray text-block_fs_s">
                        <?php echo e(trans('By logging in you accept')); ?>

                        <a href="/terms" class="text-block__link"><?php echo e(trans('the terms of use')); ?></a>
                    </div>
                    <div class="footer__terms text-block text-block_color_gray text-block_fs_s">
                        <a href="/privacy" class="text-block__link"><?php echo e(trans('privacy policy')); ?></a>
                    </div>
                    <div class="footer__age-limit-wrapper">
                        <div class="age-limit">18+</div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-3 col-md-2 col-lg-2">
                <div class="footer__nav-block">
                    <div class="footer__nav-link  <?php echo $__env->yieldContent('foo_index'); ?> ">
						<a href="/"><?php echo e(trans('Home')); ?></a>
					</div>
                    <?php if(Auth::guest()): ?>
                    <div class="footer__nav-link <?php echo $__env->yieldContent('foo_profile'); ?>">
                        <a href="#" class="modal-toggle" data-toggle="login"data-title="<?php echo e(trans('Log in')); ?> &lt;span&gt;<?php echo e(trans('to the site')); ?>&lt;/span&gt;">
                            <?php echo e(trans('Cabinet')); ?>

                        </a>
                    </div>
                    <?php else: ?>
                    <div class="footer__nav-link <?php echo $__env->yieldContent('foo_profile'); ?>">
                        <a href="/profile"><?php echo e(trans('Cabinet')); ?></a>
                    </div>
                     <?php endif; ?>
                    <div class="footer__nav-link <?php echo $__env->yieldContent('foo_faq'); ?>">
                        <a href="/faq"><?php echo e(trans('FAQ')); ?></a>
                    </div>
                    <div  class="footer__nav-link <?php echo $__env->yieldContent('foo_help'); ?>">
                       <?php if(defined('tickets')): ?>
                        <a href="/tickets"><span class="circle"><?php echo e(TICKETS); ?></span><?php echo e(trans('Help')); ?></a>
                        <?php else: ?>
                        <a href="/help"><?php echo e(trans('Help')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
                
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                <div class="footer__pay-system-header text-block text-block_fs_m"><?php echo e(trans('We accept')); ?>:</div>
                <div class="pay-system">
					<div class="pay-system__img-wrapper"><img src="/img/system/pay-icon_visa_mc.png" alt="Visa/MasterCard" title="Visa/MasterCard" class="pay-system__img"/></div>
					<div class="pay-system__img-wrapper"><img src="/img/system/pay-icon_ym.png" alt="<?php echo e(trans('Yandex.Money')); ?>" title="<?php echo e(trans('Yandex.Money')); ?>" class="pay-system__img"/></div>
					<div class="pay-system__img-wrapper"><img src="/img/system/pay-icon_qiwi.png" alt="Qiwi" title="Qiwi" class="pay-system__img"/></div>
					<div class="pay-system__img-wrapper"><img src="/img/system/pay-icon_payeer.png" alt="<?php echo e(trans('Payeer')); ?>" title="<?php echo e(trans('Payeer')); ?>" class="pay-system__img"/></div>
					<div class="pay-system__img-wrapper"><img src="/img/system/pay-icon_1.png" alt="<?php echo e(trans('Webmoney')); ?>" title="<?php echo e(trans('WebMoney')); ?>" class="pay-system__img"/></div>
					<div class="pay-system__img-wrapper"><img src="/img/system/pay-icon_2.png" alt="<?php echo e(trans('Advcache')); ?>" title="<?php echo e(trans('AdvCache')); ?>" class="pay-system__img"/></div>
					<div class="pay-system__img-wrapper"><img src="/img/system/pay-icon_3.png" alt="<?php echo e(trans('Neteller')); ?>" title="<?php echo e(trans('Neteller')); ?>" class="pay-system__img"/></div>
					
				</div>
            </div>
            <div class="col-xs-12 visible-xs">
                <div class="footer__copyright-block">
                    <div class="footer__copyright text-block text-block_fs_m">© 2017 &mdash; 2020</div>
                    <div class="footer__mini-description text-block text-block_color_gray text-block_fs_m"><?php echo e(trans('Cases with money!')); ?></div>
                    <div class="footer__terms text-block text-block_color_gray text-block_fs_m"><?php echo e(trans('Write to us')); ?>: <a href="mailto:info@azino-case.com"><span class="text-block__link">info@azino-case.com</span></a></div>
                    <div class="footer__terms text-block text-block_color_gray text-block_fs_s">
                    <?php echo e(trans('By logging in you accept')); ?>

                        <a href="/terms" class="text-block__link"><?php echo e(trans('the terms of use')); ?></a></div>
                    <div class="footer__age-limit-wrapper">
                        <div class="age-limit">18+</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div></div><?php /**PATH /var/www/www-root/data/www/azino-case.com/resources/views/layouts/footer.blade.php ENDPATH**/ ?>