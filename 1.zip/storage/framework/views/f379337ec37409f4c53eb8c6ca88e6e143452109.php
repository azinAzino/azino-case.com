<?php echo e($slot); ?>

<?php /**PATH /var/www/www-root/data/www/azino-case.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>